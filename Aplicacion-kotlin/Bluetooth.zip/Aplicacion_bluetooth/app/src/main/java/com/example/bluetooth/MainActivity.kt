package com.example.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.app.ProgressDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.content.Intent
import android.os.AsyncTask
import java.util.*
import android.bluetooth.BluetoothSocket
import android.util.Log
import android.widget.Button
import java.io.IOException
import android.widget.Toast
import android.bluetooth.BluetoothServerSocket
import android.content.pm.PackageManager
import android.widget.EditText
import android.widget.TextView
import androidx.core.app.ActivityCompat

class MainActivity: AppCompatActivity() {

    companion object {
        var m_myUUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        var m_bluetoothSocket: BluetoothSocket? = null
        lateinit var m_progress: ProgressDialog
        lateinit var m_bluetoothAdapter: BluetoothAdapter
        var m_isConnected: Boolean = false
        lateinit var m_address: String
        var m_serverSocket: BluetoothServerSocket? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val address = intent.getStringExtra(SelectDeviceActivity.EXTRA_ADDRESS)
        if (address != null) {
            m_address = address
            ConnectToDevice(this).execute()
        } else {
            Toast.makeText(this, "Dirección Bluetooth no encontrada", Toast.LENGTH_LONG).show()
            finish()
        }

        val controlNetworkInfo: Button = findViewById(R.id.control_network_info)
        val controlStorageInfo: Button = findViewById(R.id.control_storage_info)
        val controlMonitorInfo: Button = findViewById(R.id.control_monitor_info)
        val controlLedDisconnect: Button = findViewById(R.id.control_led_disconnect)
        val controlConnectWifi: Button = findViewById(R.id.control_connect_wifi)
        val controlSetIp: Button = findViewById(R.id.control_set_ip)
        val controlRealDeviceInfo: Button = findViewById(R.id.control_real_device_info) // Nuevo botón



        controlNetworkInfo.setOnClickListener { sendCommand("ip a") }
        controlStorageInfo.setOnClickListener { sendCommand("df -h") }
        controlMonitorInfo.setOnClickListener { sendCommand("sensors") }
        controlConnectWifi.setOnClickListener {
            val wifiName: EditText = findViewById(R.id.wifi_ssid)
            val wifiPassword: EditText = findViewById(R.id.wifi_password)
            val command = "nmcli dev wifi connect '${wifiName.text}' password '${wifiPassword.text}'"
            sendCommand(command)
        }
        controlSetIp.setOnClickListener {
            val ipAddress: EditText = findViewById(R.id.ip_address)
            val subnetMask: EditText = findViewById(R.id.subnet_mask)
            val gatewayAddress: EditText = findViewById(R.id.gateway_address)
            val dnsServer: EditText = findViewById(R.id.dns_address)
            val command = "sudo ifconfig eth0 ${ipAddress.text} netmask ${subnetMask.text} up && sudo route add default gw ${gatewayAddress.text} eth0 && echo \"nameserver ${dnsServer.text}\" | sudo tee /etc/resolv.conf"
            sendCommand(command)
        }

        controlRealDeviceInfo.setOnClickListener { sendCommand("htop") }

        controlLedDisconnect.setOnClickListener { disconnect() }

        val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        registerReceiver(receiver, filter)

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_SCAN
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        m_bluetoothAdapter?.startDiscovery()
    }

    private fun sendCommand(input: String) {
        if (m_bluetoothSocket != null) {
            try {
                m_bluetoothSocket!!.outputStream.write(input.toByteArray())
                m_bluetoothSocket!!.outputStream.flush()
                Log.d("BluetoothCommand", "Comando enviado: $input")
                Thread.sleep(1000)
            } catch(e: IOException) {
                e.printStackTrace()
            }
        }
    }

    private fun disconnect() {
        if (m_bluetoothSocket != null) {
            try {
                m_bluetoothSocket!!.close()
                m_bluetoothSocket = null
                m_isConnected = false
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        finish()
    }

    private val receiver = object : BroadcastReceiver() {

        override fun onReceive(context: Context, intent: Intent) {
            val action: String? = intent.action
            when(action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }
            }
        }
    }

    private class ConnectToDevice(c: Context) : AsyncTask<Void, Void, String>() {
        private var connectSuccess: Boolean = true
        private val context: Context

        init {
            this.context = c
        }

        override fun onPreExecute() {
            super.onPreExecute()
            m_progress = ProgressDialog.show(context, "Connecting...", "please wait")
        }

        @SuppressLint("MissingPermission")
        override fun doInBackground(vararg p0: Void?): String? {
            try {
                if (m_bluetoothSocket == null || !m_isConnected) {
                    m_bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
                    val device: BluetoothDevice = m_bluetoothAdapter.getRemoteDevice(m_address)
                    m_bluetoothSocket = device.createRfcommSocketToServiceRecord(m_myUUID)
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
                    m_bluetoothSocket!!.connect()
                }
            } catch (e: IOException) {
                connectSuccess = false
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if (!connectSuccess) {
                Toast.makeText(context, "No se pudo conectar al dispositivo Bluetooth", Toast.LENGTH_LONG).show()
                (context as Activity).finish()
            } else {
                m_isConnected = true
                ReadInput(context, m_bluetoothSocket!!).start() // Inicia el hilo de lectura
            }
            m_progress.dismiss()
        }
    }

    private class ReadInput(private val context: Context, private val socket: BluetoothSocket) : Thread() {

        private val inputStream = socket.inputStream
        private val buffer = ByteArray(1024)

        override fun run() {
            var numBytes: Int

            while (true) {
                numBytes = try {
                    inputStream.read(buffer)
                } catch (e: IOException) {
                    Log.e("ReadInput", "Error occurred when reading input", e)
                    break
                }

                val readMessage = String(buffer, 0, numBytes)
                (context as Activity).runOnUiThread {
                    val responseText: TextView = context.findViewById(R.id.response_text)
                    responseText.text = readMessage
                }
            }
        }
    }
}
